/* Run: node test_engine.cjs. Uses only built-in Node modules. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const engine = require('./dist/engine.js');
let passed = 0;
function test(name, fn) { fn(); passed += 1; console.log('PASS ' + name); }
function close(a, b, tol = 1e-10) { assert.ok(Math.abs(a - b) <= tol, `${a} != ${b}`); }
const fixture = {
  meta: { step_nm: 1, min_nm: 248, max_nm: 250 },
  materials: [
    { code: 2, symbol: 'Sn', name: '锡', rows: [[249, 22, 50, 28], [248, 20, 50, 30]] },
    { code: 1, symbol: 'Au', name: '金', rows: [[250, 15, 50, 35], [249, 21, 49, 30], [248, 20, 50, 30]] },
    { code: 3, symbol: 'Mo', name: '钼', rows: [[250, 0, 100, 0]] }
  ]
};
const request = { targets: [20, 50, 30], minNm: 248, maxNm: 250, materials: [1, 2, 3], tolerance: 1 };
test('exact match, deterministic material order and candidate count', () => {
  const r = engine.search(fixture, request);
  assert.equal(r.count, 6);
  assert.equal(r.feasibleCount, 3);
  assert.deepEqual(r.ranked.map(x => x.code), [1, 2, 3]);
  assert.deepEqual(r.ranked[0].pred, request.targets);
  assert.equal(r.ranked[0].nm, 248);
  assert.equal(r.ranked[0].rmse, 0);
  assert.equal(r.ranked[0].meetsTolerance, true);
});
test('known errors and RMSE hand calculation; inclusive wavelength bounds', () => {
  const r = engine.search(fixture, { ...request, minNm: 249, maxNm: 249, materials: [1] });
  assert.equal(r.count, 1);
  assert.deepEqual(r.ranked[0].errors, [1, -1, 0]);
  close(r.ranked[0].rmse, Math.sqrt(2 / 3));
  assert.equal(r.ranked[0].maxAbs, 1);
  assert.equal(r.ranked[0].meetsTolerance, true);
});
test('infeasible target retains closest candidate and marks unmet tolerance', () => {
  const r = engine.search(fixture, { ...request, materials: [3], tolerance: 0 });
  assert.equal(r.ranked[0].code, 3);
  assert.equal(r.ranked[0].meetsTolerance, false);
  assert.equal(r.feasibleCount, 0);
  close(r.ranked[0].rmse, Math.sqrt((400 + 2500 + 900) / 3));
});
test('hard tolerance chooses feasible point even when unconstrained RMSE is lower elsewhere', () => {
  const d = {
    meta: { min_nm: 248, max_nm: 250, step_nm: 1 },
    materials: [
      { code: 1, symbol: 'Au', name: '金', rows: [[248, 22.1, 48.95, 28.95], [249, 22, 48, 30]] },
      { code: 2, symbol: 'Sn', name: '锡', rows: [[248, 22.1, 48.95, 28.95]] }
    ]
  };
  const r = engine.search(d, { ...request, materials: [1, 2], tolerance: 2 });
  assert.equal(r.count, 3);
  assert.equal(r.feasibleCount, 1);
  assert.equal(r.ranked[0].nm, 249);
  assert.equal(r.ranked[0].code, 1);
  assert.equal(r.ranked[0].meetsTolerance, true);
  assert.equal(r.ranked[1].meetsTolerance, false);
  assert.ok(r.ranked[0].rmse > r.ranked[1].rmse, 'Feasibility takes precedence over unconstrained RMSE');
});
test('per-material optimum and lower-wavelength tie independent of source ordering', () => {
  const d = structuredClone(fixture);
  d.materials[1].rows.unshift([250, 20, 50, 30]);
  const r = engine.search(d, request);
  assert.equal(r.ranked[0].nm, 248);
  assert.equal(r.ranked.length, 3);
});
test('empty, unknown and nonnumeric material codes rejected; repeated codes deduplicated', () => {
  for (const codes of [[], [9], ['1']]) assert.throws(() => engine.search(fixture, { ...request, materials: codes }));
  assert.equal(engine.search(fixture, { ...request, materials: [1, 1] }).count, 3);
});
test('invalid target totals, types and nonfinite values rejected', () => {
  for (const targets of [[20, 50, 20], [NaN, 50, 50], [Infinity, 0, 0], [-1, 51, 50], [101, 0, -1], ['20', 50, 30], [20, 80]]) {
    assert.throws(() => engine.search(fixture, { ...request, targets }));
  }
  assert.doesNotThrow(() => engine.search(fixture, { ...request, targets: [20, 50, 30.01] }));
  assert.throws(() => engine.search(fixture, { ...request, targets: [20, 50, 30.02] }));
});
test('wavelength range and tolerance validation', () => {
  for (const bad of [{ minNm: 247 }, { maxNm: 251 }, { minNm: 249.5 }, { minNm: 250, maxNm: 248 }, { tolerance: -1 }, { tolerance: Infinity }, { tolerance: NaN }]) {
    assert.throws(() => engine.search(fixture, { ...request, ...bad }));
  }
  assert.throws(() => engine.search(fixture, { ...request, minNm: 248, maxNm: 249, materials: [3] }));
});
test('search does not alter targets, source rows or metadata', () => {
  const before = JSON.stringify({ fixture, request });
  engine.search(fixture, request);
  assert.equal(JSON.stringify({ fixture, request }), before);
});
test('CSV includes targets and unrounded actual candidate fields', () => {
  const r = engine.search(fixture, request);
  const csv = engine.toCSV(request.targets, r);
  const lines = csv.trimEnd().split('\r\n');
  assert.equal(lines.length, 4);
  assert.equal(lines[0].split(',').length, 17);
  assert.equal(lines[1], '1,1,Au,金,248,20,50,30,20,50,30,0,0,0,0,0,true');
});
test('CSV preserves optional query constraints on every row and rejects mismatched targets', () => {
  const query = { ...request, minNm: 249, maxNm: 250, materials: [3, 1, 1], tolerance: 1.5 };
  const r = engine.search(fixture, query);
  const lines = engine.toCSV(query.targets, r, query).trimEnd().split('\r\n').map(line => line.split(','));
  assert.deepEqual(lines[0].slice(-4), ['tolerance_pp', 'min_nm', 'max_nm', 'allowed_material_codes']);
  assert.equal(lines.length, r.ranked.length + 1);
  for (const row of lines.slice(1)) {
    assert.equal(row.length, 21);
    assert.deepEqual(row.slice(-4), ['1.5', '249', '250', '1;3']);
  }
  assert.throws(() => engine.toCSV(query.targets, r, { ...query, targets: [10, 50, 40] }));
  assert.throws(() => engine.toCSV(query.targets, r, { ...query, tolerance: NaN }));
});
test('browser UMD export works without CommonJS or a build tool', () => {
  const sandbox = { window: {} };
  sandbox.globalThis = sandbox.window;
  vm.runInNewContext(fs.readFileSync(path.join(__dirname, 'dist/engine.js'), 'utf8'), sandbox);
  assert.equal(typeof sandbox.window.OpticalEngine.search, 'function');
});

const productionPath = path.join(__dirname, 'dist/predictions.js');
if (fs.existsSync(productionPath)) {
  const sandbox = { window: {} };
  vm.runInNewContext(fs.readFileSync(productionPath, 'utf8'), sandbox, { timeout: 10000 });
  const data = sandbox.window.OPTICAL_DATA;
  test('production grid is complete, unique, finite and ordered', () => {
    assert.equal(data.materials.length, 6);
    assert.equal(data.meta.min_nm, 248);
    assert.equal(data.meta.max_nm, 2000);
    assert.equal(data.meta.step_nm, 1);
    for (const m of data.materials) {
      assert.equal(m.rows.length, 1753);
      for (let i = 0; i < m.rows.length; i++) {
        assert.equal(m.rows[i][0], 248 + i);
        assert.ok(m.rows[i].every(Number.isFinite));
      }
    }
  });
  // Independently sort all candidates instead of calling engine score helpers.
  function independent(data, opt) {
    const all = [];
    for (const m of data.materials) {
      if (!opt.materials.includes(m.code)) continue;
      for (const row of m.rows) {
        if (row[0] < opt.minNm || row[0] > opt.maxNm) continue;
        const differences = row.slice(1).map((v, i) => v - opt.targets[i]);
        const score = (differences[0] ** 2 + differences[1] ** 2 + differences[2] ** 2) / 3;
        const feasible = differences.every(v => Math.abs(v) <= opt.tolerance);
        all.push({ code: m.code, nm: row[0], score, feasible });
      }
    }
    all.sort((a, b) => Number(b.feasible) - Number(a.feasible) || a.score - b.score || a.code - b.code || a.nm - b.nm);
    const seen = new Set();
    return { count: all.length, feasibleCount: all.filter(x => x.feasible).length,
      ranked: all.filter(x => !seen.has(x.code) && seen.add(x.code)) };
  }
  for (const [i, opt] of [
    { targets: [20, 50, 30], minNm: 248, maxNm: 2000, materials: [1, 2, 3, 4, 5, 6], tolerance: 2 },
    { targets: [5, 90, 5], minNm: 400, maxNm: 700, materials: [1, 3, 5], tolerance: 0.5 },
    { targets: [10, 30, 60], minNm: 248, maxNm: 400, materials: [2, 4, 6], tolerance: 2 },
    { targets: [100, 0, 0], minNm: 600, maxNm: 600, materials: [1, 2, 3, 4, 5, 6], tolerance: 0 }
  ].entries()) {
    test('production inverse agrees with independent exhaustive sort, case ' + (i + 1), () => {
      const actual = engine.search(data, opt);
      const expected = independent(data, opt);
      assert.equal(actual.count, expected.count);
      assert.equal(actual.feasibleCount, expected.feasibleCount);
      assert.equal(actual.ranked.length, expected.ranked.length);
      actual.ranked.forEach((row, j) => {
        assert.equal(row.code, expected.ranked[j].code);
        assert.equal(row.nm, expected.ranked[j].nm);
        assert.equal(row.meetsTolerance, expected.ranked[j].feasible);
        close(row.rmse, Math.sqrt(expected.ranked[j].score));
      });
    });
  }
} else {
  console.log('SKIP production grid checks: predictions.js has not been exported yet.');
}
console.log(`ALL ${passed} ENGINE CHECKS PASSED`);
