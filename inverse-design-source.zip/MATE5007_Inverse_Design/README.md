# Thin Film Optical Inverse Design

给定目标透射率 T、反射率 R 和吸收率 A，通过已复现的 CatBoost 正向模型，反求材料和工作波长。

## 直接打开网页

解压后双击 `dist/index.html`。所有脚本和预测数据已包含在包内，**打开网页无需安装 Python，也不依赖网络**。

输入 T、R、A（百分数，总和 100），选择材料、波长区间和允许偏差，再执行逆向设计。
结果包含推荐材料、波长、三个预测值、目标偏差、备选方案、T/R/A 预测光谱和可切换的目标匹配 RMSE 曲线，可导出 CSV。
只修改输入不会把旧结果当作新结果；需重新执行搜索。

### 课堂演示示例

点击“Reflection”，保持六种材料全选、248–2000 nm、允许偏差 ±2 个百分点，再点击“Find design”。
目标 T=7%、R=90%、A=3% 时，程序推荐 Mo（钼）、1589 nm；预测约为
7.218%、90.304%、2.417%，目标匹配 RMSE 为 0.400 个百分点。
可在结果表中切换其他材料，或导出 CSV 留存目标、预测、误差和搜索条件。

## 本地英文界面更新（2026-11-13）

- 标题与界面统一为英文，参照作者英文应用的参数命名；默认显示逆向设计。
- `Forward prediction` 输入材料和整数波长，返回与逆向搜索共用的同一模型网格预测。
- `Spectrum` 展示 T/R/A；`Target error` 展示当前目标下的 RMSE。没有新增训练、测量或模型数据。
- 原作者应用的固定 ±2.5 范围未作为统计置信区间复用；详见 `docs/INTERFACE_COMPARISON.md`。
- 修改输入后，旧结果会变淡并提示更新；逆向 CSV 在重新计算前禁用。
- 本轮改动仅保存在本地，未推送 GitHub，也未开启 GitHub Pages。

## 误差与置信区间

- 主界面的 `Tolerance`、偏差和 `Target RMSE` 衡量预测与用户目标之间的距离。
- 折叠的 `About this model & sources` 中，`Model validation` 展示 T/R/A 在原有 264 条留出记录上的 MAE，以及 MAE 的 95% bootstrap 置信区间。
- 区间直接来自已保存的复现 `metrics.csv`：固定模型和预测，以记录为单位有放回抽样 1,000 次，seed=42，取 2.5% 和 97.5% 分位数。它们描述测试集 MAE 的抽样变动，**不是单个材料／波长预测的区间**，也不包含重新训练模型带来的变化。

网页读取随包附带的 `dist/validation.js`，离线打开也能显示指标，不需要重新计算 bootstrap。
导出脚本核对源文件哈希、测试集行号，并从保存的 264 条预测独立复算 MAE；它不会训练模型或更改预测网格。
只保留三行 CatBoost 指标和精简来源信息，不复制运行机器的环境路径。

## 搜索方法

- 六种材料：Au、Sn、Mo、Ni、Cu、Al；波长 248–2000 nm，搜索步长 1 nm。
- 正向模型保持复现设置：论文表 3 参数、seed=42、作者数据中的 1,056 条训练记录。
- 将模型在 10,518 个材料—波长组合上的预测预先导出，浏览器进行完整网格搜索。
  **这 10,518 条是模型预测，不是新增的实验数据。原始数据库仍为 1,320 条。**
- 若三个预测参数与目标的绝对偏差均不超过指定容差，则候选满足设计要求。
- 对每种材料，优先选满足偏差要求的候选，并在其中最小化 RMSE；若该材料没有可行候选，
  返回其最小 RMSE 的近似方案。全局排序也优先显示满足要求的方案。
- 目标函数为 `sqrt(((T_pred-T_target)^2+(R_pred-R_target)^2+(A_pred-A_target)^2)/3)`。
- RMSE 和允许偏差的单位为百分点。容差是设计要求，不是统计置信区间。
- 搜索给出所选 **1 nm 网格**上的解，不声称已证明连续波长空间的最优性。
- 仅改变材料与工作波长；膜厚和制备条件保持原研究的数据条件。预测值不进行裁剪、强制归一化或物理约束修改。
- 原模型在少量网格点会产生轻微负预测；网页保留数值并提示物理范围越界。满足目标偏差不代表物理有效。

这是“正向代理模型＋数值优化”的逆向设计实现，不是用实验标签直接查表。
网页显示的预测性能指标来自正向模型的留出数据评估，不能当作逆向方案的新增实验验证。

## 代码与文件

| 文件 | 用途 |
|---|---|
| `dist/index.html`、`styles.css`、`app.js` | 输入、结果、图表与导出界面 |
| `dist/engine.js` | 输入验证、约束条件、目标函数与网格搜索 |
| `dist/predictions.js` | 经过核验的模型预测网格 |
| `dist/validation.js` | 已保存的测试集 MAE、95% bootstrap 区间及来源信息 |
| `python/export_predictions.py` | 从已拟合模型重新导出预测；模型缺失时按固定训练划分恢复 |
| `python/export_validation.py` | 用 Python 标准库导出已有评估指标；不训练模型或重新抽样 |
| `source/CatBoost.joblib` | 训练好的模型 |
| `source/DATASET_FINAL.xlsx` | 作者原始数据库 |
| `source/split_indices.json` | 固定训练集／测试集行号 |
| `source/CatBoost_reference_predictions.csv` | 上一次复现保存的预测，用于恢复核验 |
| `source/export_audit.json` | 哈希、软件版本、预测恢复误差与导出精度 |
| `source/validation_metrics.csv`、`validation_provenance.json` | 三行 CatBoost 指标与可核验的原始结果文件哈希、评估方法 |
| `test_engine.cjs` | 数值搜索、边界条件与导出功能检查 |
| `test_validation.cjs` | 评估来源、指标数值、测试集划分和确定性导出检查 |

## 可选：重建与检查

网页使用者无需安装下述依赖；以下命令仅供检查或修改代码的人员使用。
导出脚本已在 Python 3.12.14 下验证；搜索测试已在 Node.js 24.22.1 下验证。
只有重新导出模型预测才需要 Python 依赖；只有运行 JavaScript 自动检查才需要 Node.js。

```bash
python -m pip install -r python/requirements.txt
python python/export_predictions.py
node test_engine.cjs
```

只重新导出或检查评估指标时，无需安装 Python 第三方依赖：

```bash
python3 python/export_validation.py
node test_validation.cjs
```

若要从原复现目录更新指标快照，运行 `python3 python/export_validation.py --import-from /path/to/reproduction`。
来源为该目录中的 `results/submission/metrics.csv`、`run_manifest.json`、`split_indices.json`、`CatBoost_predictions.csv`，以及 `reproduce.py` 的评估算法；源测试划分与本包不一致时会拒绝导入。

Python 导出脚本使用保存的同一训练集和同一超参数，不把原测试集加入训练。
环境切换后恢复的模型与原复现的全部 264 条测试预测最大差异为约 2.84e-14 个百分点。
导出八位小数对预测造成的最大舍入误差小于 5.1e-9 个百分点。

如需本地 HTTP 服务，可在项目根目录运行 `python -m http.server 8765 --directory dist`，
然后打开 http://localhost:8765 。这不是打开网页的必需步骤。

## 来源与边界

Thomas et al., *Enhanced prediction and optimization of thin metal film optical properties
using optimized ensemble learning models*, Scientific Reports 15, 43523 (2025).

- 论文：https://doi.org/10.1038/s41598-025-27524-6
- 公开代码／数据：https://github.com/kevint992-debug/OptiM-AI
- 固定版本：`c1f2d69a06bd8d6b4ca6536dbad178bffbc5017e`

本项目是课程应用扩展，使用作者数据和成熟模型，不声称发现新材料或完成新实验。
原研究与数据库归原作者；本项目代码整理和界面实现使用了 AI 辅助。原始数据库及已保存的复现预测不变。
