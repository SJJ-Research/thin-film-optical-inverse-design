"""Build the downloadable coursework bundle with Python's standard library.

Run from any directory: python python/package_submission.py
The archive includes the offline page, model, source data, scripts and checks.
It excludes Git credentials, caches and the archive itself.
"""

from hashlib import sha256
from pathlib import Path
from zipfile import ZIP_DEFLATED, ZipFile

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "dist" / "inverse-design-source.zip"
PREFIX = "MATE5007_Inverse_Design"


def main():
    files = [ROOT / "README.md", ROOT / "VALIDATION.txt", ROOT / "test_engine.cjs"]
    for folder in ("dist", "source", "python", "docs"):
        files.extend(
            path for path in (ROOT / folder).rglob("*")
            if path.is_file()
            and path != OUTPUT
            and "__pycache__" not in path.parts
            and path.suffix not in (".pyc", ".zip")
        )
    files = sorted(set(files))
    missing = [str(path.relative_to(ROOT)) for path in files if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing submission files: {missing}")

    hashes = []
    with ZipFile(OUTPUT, "w", ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(ROOT).as_posix()
            archive.write(path, f"{PREFIX}/{relative}")
            hashes.append(f"{sha256(path.read_bytes()).hexdigest()}  {relative}")
        archive.writestr(f"{PREFIX}/SHA256SUMS.txt", "\n".join(hashes) + "\n")
    with ZipFile(OUTPUT) as archive:
        corrupt = archive.testzip()
        if corrupt:
            raise ValueError(f"ZIP integrity check failed: {corrupt}")
    print(f"Created {OUTPUT} ({len(files) + 1} files, {OUTPUT.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
