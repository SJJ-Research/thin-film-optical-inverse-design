"""Export existing CatBoost held-out metric intervals for the static website.

Uses only the Python standard library. It reads saved evaluation results;
it never fits a model, resamples predictions or alters predictions.js.

Refresh the compact, sanitized source snapshots from the reproduction:
    python3 python/export_validation.py --import-from /path/to/reproduction
Rebuild the browser asset from the bundled snapshots:
    python3 python/export_validation.py
"""

import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "source"
TARGETS = ("T", "R", "A")
COLUMNS = ("model", "target", "MAE", "MAE_ci_low", "MAE_ci_high", "R2")
METRICS_PATH = SOURCE / "validation_metrics.csv"
PROVENANCE_PATH = SOURCE / "validation_provenance.json"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def select_metrics(rows):
    selected = [row for row in rows if row["model"] == "CatBoost"]
    if len(selected) != 3 or {row["target"] for row in selected} != set(TARGETS):
        raise ValueError("Expected exactly one CatBoost row for T, R and A.")
    return sorted(selected, key=lambda row: TARGETS.index(row["target"]))


def import_snapshots(reproduction):
    run = reproduction / "results" / "submission"
    metrics_file = run / "metrics.csv"
    manifest_file = run / "run_manifest.json"
    split_file = run / "split_indices.json"
    predictions_file = run / "CatBoost_predictions.csv"
    evaluation_file = reproduction / "reproduce.py"
    manifest, split = read_json(manifest_file), read_json(split_file)
    if manifest["status"] != "completed":
        raise ValueError("The source evaluation run is not complete.")
    if split != read_json(SOURCE / "split_indices.json"):
        raise ValueError("The source evaluation uses a different held-out split.")
    if read_csv(predictions_file) != read_csv(SOURCE / "CatBoost_reference_predictions.csv"):
        raise ValueError("The source evaluation differs from the saved reference predictions.")
    evaluation_source = evaluation_file.read_text(encoding="utf-8")
    if "rng.choice(len(y), len(y), replace=True)" not in evaluation_source or "np.percentile(boot[key], [2.5, 97.5])" not in evaluation_source:
        raise ValueError("Review the source bootstrap method before importing changed evaluation code.")
    selected = select_metrics(read_csv(metrics_file))
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=COLUMNS, lineterminator="\n", extrasaction="ignore")
    writer.writeheader()
    writer.writerows(selected)
    METRICS_PATH.write_text(buffer.getvalue(), encoding="utf-8")
    provenance = {
        "model": "CatBoost",
        "test_rows": len(split["test"]),
        "train_rows": len(split["train"]),
        "confidence_level": 0.95,
        "bootstrap_resamples": manifest["bootstrap_resamples"],
        "bootstrap_seed": manifest["seed"],
        "bootstrap_method": "percentile, 2.5th and 97.5th percentiles",
        "resampling_unit": "held-out record, with replacement",
        "fixed_predictions": True,
        "interval_scope": "held-out MAE, not individual predictions",
        "origin": {
            "metrics": "reproduction/results/submission/metrics.csv",
            "manifest": "reproduction/results/submission/run_manifest.json",
            "evaluation": "reproduction/reproduce.py:evaluate",
            "metrics_sha256": sha256(metrics_file),
            "manifest_sha256": sha256(manifest_file),
            "evaluation_sha256": sha256(evaluation_file),
        },
        "snapshot_sha256": sha256(METRICS_PATH),
        "split_sha256": sha256(SOURCE / "split_indices.json"),
        "reference_predictions_sha256": sha256(SOURCE / "CatBoost_reference_predictions.csv"),
    }
    PROVENANCE_PATH.write_text(json.dumps(provenance, indent=2) + "\n", encoding="utf-8")


def export():
    provenance = read_json(PROVENANCE_PATH)
    for source_path, key in [
        (METRICS_PATH, "snapshot_sha256"),
        (SOURCE / "split_indices.json", "split_sha256"),
        (SOURCE / "CatBoost_reference_predictions.csv", "reference_predictions_sha256"),
    ]:
        if sha256(source_path) != provenance[key]:
            raise ValueError(f"Source hash does not match provenance: {source_path.name}")
    split = read_json(SOURCE / "split_indices.json")
    reference = read_csv(SOURCE / "CatBoost_reference_predictions.csv")
    if len(split["test"]) != provenance["test_rows"] or len(reference) != provenance["test_rows"]:
        raise ValueError("Held-out row counts do not agree.")
    if set(map(int, (row["row_id"] for row in reference))) != set(split["test"]):
        raise ValueError("Reference predictions do not cover the declared held-out rows.")
    resamples = provenance["bootstrap_resamples"]
    if not isinstance(resamples, int) or resamples < 1 or provenance["confidence_level"] != 0.95:
        raise ValueError("Expected a documented positive bootstrap count and a 95% interval.")
    metrics = []
    for row in select_metrics(read_csv(METRICS_PATH)):
        target = row["target"]
        mae, low, high, r2 = [float(row[key]) for key in ("MAE", "MAE_ci_low", "MAE_ci_high", "R2")]
        if not all(math.isfinite(x) for x in (mae, low, high, r2)) or not 0 <= low <= mae <= high:
            raise ValueError(f"Invalid saved metric interval for {target}.")
        checked_mae = math.fsum(abs(float(p[target + "_true"]) - float(p[target + "_pred"])) for p in reference) / len(reference)
        if not math.isclose(checked_mae, mae, rel_tol=0, abs_tol=1e-12):
            raise ValueError(f"Saved {target} MAE differs from the held-out reference predictions.")
        metrics.append({"target": target, "mae_pp": mae, "mae_ci95_pp": [low, high], "r2": r2})
    result = {"schema_version": 1, "meta": provenance, "metrics": metrics}
    output = ROOT / "dist" / "validation.js"
    output.write_text("// Generated by python/export_validation.py; saved held-out metrics only.\nwindow.OPTICAL_VALIDATION = " + json.dumps(result, indent=2) + ";\n", encoding="utf-8")
    print(f"Exported {len(metrics)} targets; {len(reference)} held-out records; {resamples} bootstrap resamples.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--import-from", type=Path, help="Original reproduction directory; only sanitized metrics/provenance are copied")
    args = parser.parse_args()
    if args.import_from:
        import_snapshots(args.import_from.resolve())
    export()
