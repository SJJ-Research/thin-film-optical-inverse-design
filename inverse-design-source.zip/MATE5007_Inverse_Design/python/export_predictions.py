"""Export predictions from the reproduced CatBoost model for inverse design.

The browser searches a precomputed 1 nm grid of model predictions. These
predictions are not additional experimental measurements. An existing fitted
model is reused; if absent, the same model is fitted on the saved 1,056
training rows. The 264 held-out rows are used only for verification and scoring.

Run from the project root: python python/export_predictions.py
"""

import hashlib
import json
import sys
from pathlib import Path

import catboost
import joblib
import numpy as np
import pandas as pd
import sklearn
from catboost import CatBoostRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.multioutput import MultiOutputRegressor


ROOT = Path(__file__).resolve().parents[1]
SOURCE_DIR = ROOT / "source"
DIST_DIR = ROOT / "dist"
DATASET_SHA256 = (
    "1b3232a1e95b5b941d906b2d988acfd3881588ec415cf007aafaf92dd2cf0f34"
)
FEATURE_COLUMNS = ["nm", "Type"]
TARGET_COLUMNS = ["T", "R", "A"]
MATERIALS = [
    (1, "Au", "金"),
    (2, "Sn", "锡"),
    (3, "Mo", "钼"),
    (4, "Ni", "镍"),
    (5, "Cu", "铜"),
    (6, "Al", "铝"),
]
MIN_WAVELENGTH_NM = 248
MAX_WAVELENGTH_NM = 2000
GRID_STEP_NM = 1
EXPORT_DECIMALS = 8


def sha256_file(path: Path) -> str:
    """Return a file hash for input verification and the export audit."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_dataset_and_split():
    """Read the unchanged author data and previously saved row assignments."""
    data_path = SOURCE_DIR / "DATASET_FINAL.xlsx"
    if sha256_file(data_path) != DATASET_SHA256:
        raise ValueError("The dataset differs from the pinned author file.")

    frame = pd.read_excel(data_path)
    expected_columns = FEATURE_COLUMNS + TARGET_COLUMNS
    if frame.shape != (1320, 5) or list(frame.columns) != expected_columns:
        raise ValueError("Expected 1,320 rows with columns nm, Type, T, R, A.")

    split_path = SOURCE_DIR / "split_indices.json"
    split = json.loads(split_path.read_text(encoding="utf-8"))
    train_rows, test_rows = split["train"], split["test"]

    # The saved split refers to these exact rows, in the source row order.
    features = frame[FEATURE_COLUMNS].to_numpy()
    targets = frame[TARGET_COLUMNS].to_numpy()
    return data_path, features, targets, train_rows, test_rows


def load_or_restore_model(features, targets, train_rows):
    """Reuse the fitted model, or refit the published Table 3 configuration."""
    model_path = SOURCE_DIR / "CatBoost.joblib"
    if model_path.exists():
        return joblib.load(model_path), model_path

    # One regressor per optical property, as in the reproduction.
    # Material codes remain numeric, as in the author's main training cell.
    estimator = CatBoostRegressor(
        random_seed=42,
        loss_function="RMSE",
        verbose=False,
        thread_count=4,
        allow_writing_files=False,
        n_estimators=1200,
        depth=10,
        learning_rate=0.05,
        l2_leaf_reg=3,
    )
    model = MultiOutputRegressor(estimator)
    model.fit(features[train_rows], targets[train_rows])
    joblib.dump(model, model_path, compress=3)
    return model, model_path


def verify_held_out_predictions(model, features, targets, test_rows):
    """Check recovery against the saved run and calculate held-out metrics.

    Scores are uniform means across T, R and A. MAE is in percentage points;
    it measures forward prediction error, not inverse-design target mismatch.
    """
    reference_path = SOURCE_DIR / "CatBoost_reference_predictions.csv"
    reference = pd.read_csv(reference_path)
    if reference["row_id"].tolist() != test_rows:
        raise ValueError("Reference prediction rows do not match the test split.")

    restored = model.predict(features[test_rows])
    prediction_columns = [f"{target}_pred" for target in TARGET_COLUMNS]
    previous = reference[prediction_columns].to_numpy()
    recovery_error = float(np.max(np.abs(restored - previous)))
    np.testing.assert_allclose(restored, previous, atol=1e-7, rtol=0)

    metrics = {
        "r2": float(r2_score(targets[test_rows], restored)),
        "mae": float(mean_absolute_error(targets[test_rows], restored)),
    }
    return recovery_error, metrics


def predict_wavelength_grid(model):
    """Predict each material on the integer-nm grid without altering outputs."""
    wavelengths = np.arange(
        MIN_WAVELENGTH_NM, MAX_WAVELENGTH_NM + 1, GRID_STEP_NM
    )
    materials = []
    maximum_rounding_error = 0.0

    for code, symbol, name in MATERIALS:
        features = np.column_stack(
            [wavelengths, np.full(len(wavelengths), code)]
        )
        predictions = model.predict(features)
        rounded = np.round(predictions, EXPORT_DECIMALS)
        maximum_rounding_error = max(
            maximum_rounding_error,
            float(np.abs(predictions - rounded).max()),
        )

        # Browser row format: [wavelength_nm, T_pct, R_pct, A_pct].
        # Do not clip or normalize: these are the model's original outputs.
        rows = [
            [int(wavelength), *[float(value) for value in prediction]]
            for wavelength, prediction in zip(wavelengths, rounded)
        ]
        materials.append(
            {"code": code, "symbol": symbol, "name": name, "rows": rows}
        )

    return materials, maximum_rounding_error


def build_audit(
    data_path,
    model_path,
    train_rows,
    test_rows,
    materials,
    recovery_error,
    rounding_error,
    model_metrics,
):
    """Record provenance, numerical checks and software versions."""
    return {
        "model": "CatBoost",
        "min_nm": MIN_WAVELENGTH_NM,
        "max_nm": MAX_WAVELENGTH_NM,
        "step_nm": GRID_STEP_NM,
        "train_rows": len(train_rows),
        "test_rows": len(test_rows),
        "dataset_rows": len(train_rows) + len(test_rows),
        "prediction_count": sum(len(m["rows"]) for m in materials),
        "source_doi": "10.1038/s41598-025-27524-6",
        "model_metrics": model_metrics,
        "target_order": TARGET_COLUMNS,
        "model_sha256": sha256_file(model_path),
        "dataset_sha256": sha256_file(data_path),
        "maximum_export_rounding_error_pp": rounding_error,
        "maximum_difference_vs_original_reproduction_pp": recovery_error,
        "versions": {
            "python": sys.version.split()[0],
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "scikit-learn": sklearn.__version__,
            "catboost": catboost.__version__,
        },
        "prediction_source": (
            "Fitted-model inference on an integer-nm grid; not measured labels"
        ),
        "training_protocol": (
            "Paper Table 3 parameters; original 1056 train rows; seed 42"
        ),
    }


def write_export(materials, audit):
    """Write a browser-loadable data file and the matching JSON audit."""
    payload = {"meta": audit, "materials": materials}
    javascript = "window.OPTICAL_DATA = " + json.dumps(
        payload, ensure_ascii=False, separators=(",", ":")
    ) + ";\n"
    (DIST_DIR / "predictions.js").write_text(javascript, encoding="utf-8")

    audit_text = json.dumps(audit, indent=2, ensure_ascii=False)
    (SOURCE_DIR / "export_audit.json").write_text(
        audit_text + "\n", encoding="utf-8"
    )
    print(audit_text)


def main():
    data_path, features, targets, train_rows, test_rows = load_dataset_and_split()
    model, model_path = load_or_restore_model(features, targets, train_rows)
    recovery_error, model_metrics = verify_held_out_predictions(
        model, features, targets, test_rows
    )
    materials, rounding_error = predict_wavelength_grid(model)
    audit = build_audit(
        data_path,
        model_path,
        train_rows,
        test_rows,
        materials,
        recovery_error,
        rounding_error,
        model_metrics,
    )
    write_export(materials, audit)


if __name__ == "__main__":
    main()
