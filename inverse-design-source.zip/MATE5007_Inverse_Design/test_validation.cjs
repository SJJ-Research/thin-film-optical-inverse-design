/* Run: node test_validation.cjs. Built-in Node modules only. */
'use strict';
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const crypto = require('node:crypto');
const {execFileSync} = require('node:child_process');
const read = file => fs.readFileSync(path.join(__dirname, file), 'utf8');
const hash = file => crypto.createHash('sha256').update(fs.readFileSync(path.join(__dirname, file))).digest('hex');
// These exported scientific CSV files have no quoted or comma-containing fields.
function csv(file) {
  const [header, ...lines] = read(file).trim().split(/\r?\n/).map(line => line.split(','));
  return lines.map(cells => {
    assert.equal(cells.length, header.length);
    return Object.fromEntries(header.map((key, i) => [key, cells[i]]));
  });
}
let passed = 0;
function test(name, fn) { fn(); passed++; console.log('PASS ' + name); }
const scope = {window: {}};
vm.runInNewContext(read('dist/validation.js'), scope, {timeout: 1000});
const validation = JSON.parse(JSON.stringify(scope.window.OPTICAL_VALIDATION));
const provenance = JSON.parse(read('source/validation_provenance.json'));
const reference = csv('source/CatBoost_reference_predictions.csv');
const snapshot = csv('source/validation_metrics.csv');
const split = JSON.parse(read('source/split_indices.json'));

test('offline asset contains three documented CatBoost metric intervals', () => {
  assert.equal(validation.schema_version, 1);
  assert.equal(validation.meta.model, 'CatBoost');
  assert.deepEqual(validation.metrics.map(row => row.target), ['T', 'R', 'A']);
  assert.equal(validation.meta.confidence_level, .95);
  assert.equal(validation.meta.bootstrap_resamples, 1000);
  assert.equal(validation.meta.bootstrap_seed, 42);
  assert.equal(validation.meta.fixed_predictions, true);
  assert.equal(validation.meta.interval_scope, 'held-out MAE, not individual predictions');
});

test('source snapshots and evaluation references agree with their recorded hashes', () => {
  assert.deepEqual(validation.meta, provenance);
  assert.equal(hash('source/validation_metrics.csv'), provenance.snapshot_sha256);
  assert.equal(hash('source/split_indices.json'), provenance.split_sha256);
  assert.equal(hash('source/CatBoost_reference_predictions.csv'), provenance.reference_predictions_sha256);
  assert.equal(provenance.origin.metrics, 'reproduction/results/submission/metrics.csv');
  for (const key of ['metrics_sha256', 'manifest_sha256', 'evaluation_sha256']) {
    assert.match(provenance.origin[key], /^[a-f0-9]{64}$/);
  }
  assert.ok(!JSON.stringify(provenance).includes('/Users/'), 'Provenance must not expose a local home path');
});

test('validation uses exactly the 264 held-out rows, with no training rows mixed in', () => {
  assert.equal(provenance.test_rows, 264);
  assert.equal(provenance.train_rows, 1056);
  assert.equal(reference.length, provenance.test_rows);
  assert.equal(split.test.length, provenance.test_rows);
  assert.equal(split.train.length, provenance.train_rows);
  assert.deepEqual(reference.map(row => Number(row.row_id)).sort((a,b) => a-b), [...split.test].sort((a,b) => a-b));
  const training = new Set(split.train);
  assert.ok(split.test.every(row => !training.has(row)));
});

test('all displayed metrics and CI bounds retain the exact saved values', () => {
  assert.equal(snapshot.length, 3);
  for (const metric of validation.metrics) {
    const saved = snapshot.find(row => row.target === metric.target);
    assert.equal(saved.model, 'CatBoost');
    assert.equal(metric.mae_pp, Number(saved.MAE));
    assert.deepEqual(metric.mae_ci95_pp, [Number(saved.MAE_ci_low), Number(saved.MAE_ci_high)]);
    assert.equal(metric.r2, Number(saved.R2));
    assert.ok(metric.mae_ci95_pp[0] >= 0 && metric.mae_ci95_pp[0] <= metric.mae_pp && metric.mae_pp <= metric.mae_ci95_pp[1]);
  }
});

test('MAE independently recomputed from saved held-out predictions matches the table', () => {
  for (const metric of validation.metrics) {
    const mae = reference.reduce((sum, row) => sum + Math.abs(Number(row[metric.target + '_true']) - Number(row[metric.target + '_pred'])), 0) / reference.length;
    assert.ok(Math.abs(mae - metric.mae_pp) < 1e-12, `${metric.target} MAE differs from held-out predictions`);
  }
});

test('export is deterministic and leaves the prediction grid and search engine untouched', () => {
  const before = ['dist/validation.js', 'dist/predictions.js', 'dist/engine.js'].map(hash);
  execFileSync('python3', ['python/export_validation.py'], {cwd: __dirname, encoding: 'utf8'});
  assert.deepEqual(['dist/validation.js', 'dist/predictions.js', 'dist/engine.js'].map(hash), before);
});

console.log(`ALL ${passed} VALIDATION CHECKS PASSED`);
