# Author interface and local UI plan

Evidence checked: **13 November 2026 (Hong Kong time)**.
This is an off-page implementation note. It is not intended as website copy.

## Author source evidence

- Author application source:
  https://huggingface.co/spaces/kevint992/OptiM-AI/blob/main/app.py
- Inspected application revision:
  `aa4a7c695395e8ad9cf88f27843359b983bc8605`
- Revision-specific source:
  https://huggingface.co/spaces/kevint992/OptiM-AI/blob/aa4a7c695395e8ad9cf88f27843359b983bc8605/app.py
- Author training notebook:
  https://github.com/kevint992-debug/OptiM-AI/blob/main/FINAL_ENSEMBLE_METAL_PAPER_FINAL_ML.ipynb
- Verified notebook Git blob:
  `3dfe7ba53c4d6fb54d687bf8d3146a6410246d83`
  The current public notebook was confirmed byte-identical to the local reference.
- Paper: https://doi.org/10.1038/s41598-025-27524-6

The application source uses an English Gradio `gr.Interface` around
`predict(wavelength, metal)`. It accepts a wavelength in the stated
200–2000 nm range and a material code from 1 to 6. It returns transmittance,
reflectance and absorptance, each with a fixed ±2.5 margin labelled as a
confidence interval, plus prediction latency. It does not implement an inverse
search from target T/R/A to material and wavelength.

The Space was sleeping when inspected. These observations describe the source,
not a successful live prediction during this review. No additional tabs, plots
or optimization features are inferred from the notebook: it contains model
training and diagnostic figures, but no Gradio application definition.

The fixed ±2.5 margin is not, by itself, evidence of a calibrated confidence
level or prediction coverage. Our interface will not reuse it as a statistical
confidence interval. The inverse-design tolerance is a user-specified target
matching requirement, with a different meaning.

## Planned local interface

| Area | Decision |
|---|---|
| Language | English, following the author's interface language. |
| Style | Retain the existing teal visual style and concise labels. |
| Primary workflow | Enter target T/R/A, choose materials and wavelength bounds, then run inverse design. |
| Secondary workflow | Choose a material and integer wavelength to inspect the forward prediction. |
| Forward values | Read the same exported CatBoost grid used by inverse design. No separate model or interpolation. |
| Spectrum | Show T, R and A against wavelength for the selected material, with the selected wavelength marked. |
| Target mismatch | Retain a separate RMSE-versus-wavelength view for the active inverse target. |
| Results | Show material, wavelength, predicted T/R/A, target deviations and whether all deviations satisfy the tolerance. |
| Interval display | No fixed confidence band. Do not present target tolerance as model uncertainty. |

The visible product copy should remain short. Provenance and these detailed
method comparisons belong in this document or a compact optional reference area,
not in the main design workflow.

## Numerical contract

The author data actually provided for this project cover **248–2000 nm**.
Both local workflows use that range, inclusive, on the existing **1 nm grid**.
Six materials × 1,753 wavelengths give 10,518 predicted combinations; these
are predictions from the already reproduced model, not additional measured data.

- Material codes remain 1=Au, 2=Sn, 3=Mo, 4=Ni, 5=Cu and 6=Al.
- The response order remains T, R, A. Values are percentages; deviations and
  target-matching RMSE are percentage points.
- Forward lookup at `(material, wavelength)` returns exactly the three values
  in that exported row. Inputs outside the supported range or between integer
  grid points are rejected rather than silently clipped or rounded.
- Spectrum values come from the same rows. Connecting plotted points is a
  visual aid, not a new numerical interpolation model.
- The selected spectrum marker and the forward response must agree with the
  inverse candidate at the same material and wavelength.
- The mismatch chart uses
  `sqrt(((T-T_target)^2 + (R-R_target)^2 + (A-A_target)^2) / 3)`.
  Forward response values do not depend on the inverse targets or tolerance.
- Preserve raw exported model predictions, including slight negatives or sums
  different from 100. Do not clip, normalize or apply a new physical correction.
  Show a concise warning for values outside 0–100; chart limits must not conceal
  them.
- Existing inverse rules remain: prefer candidates meeting all three tolerance
  bounds, then minimize RMSE; otherwise return the closest approximate result.

This change adds interface workflows and visualizations around the existing
reproduction. It does not retrain the author's model, introduce a new training
dataset, claim new measurements, or claim new experimental validation.

## Local review status

The interface changes are local for review. Publication, uploading and remote
updates are outside the current authorization and require the user's approval.
